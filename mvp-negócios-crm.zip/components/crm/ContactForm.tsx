
import React, { useState, useEffect } from 'react';
import { Contact, ContactStatus } from '../../types';
import { Button } from '../ui/Button';
import { Input } from '../ui/Input';
import { Textarea } from '../ui/Textarea';
import { Select } from '../ui/Select';
import { useAppContext } from '../../contexts/AppContext';

interface ContactFormProps {
  onClose: () => void;
  contactToEdit?: Contact;
}

export const ContactForm: React.FC<ContactFormProps> = ({ onClose, contactToEdit }) => {
  const { addContact, updateContact } = useAppContext();
  const [name, setName] = useState('');
  const [whatsapp, setWhatsapp] = useState('');
  const [email, setEmail] = useState('');
  const [status, setStatus] = useState<ContactStatus>(ContactStatus.LEAD);
  const [notes, setNotes] = useState('');
  const [errors, setErrors] = useState<{ [key: string]: string }>({});

  useEffect(() => {
    if (contactToEdit) {
      setName(contactToEdit.name);
      setWhatsapp(contactToEdit.whatsapp);
      setEmail(contactToEdit.email || '');
      setStatus(contactToEdit.status);
      setNotes(contactToEdit.notes || '');
    } else {
      // Reset for new contact
      setName('');
      setWhatsapp('');
      setEmail('');
      setStatus(ContactStatus.LEAD);
      setNotes('');
    }
  }, [contactToEdit]);

  const validate = (): boolean => {
    const newErrors: { [key: string]: string } = {};
    if (!name.trim()) newErrors.name = 'Nome é obrigatório.';
    if (!whatsapp.trim()) {
      newErrors.whatsapp = 'WhatsApp é obrigatório.';
    } else if (!/^\+?[0-9\s-()]{10,}$/.test(whatsapp)) {
      newErrors.whatsapp = 'Número de WhatsApp inválido.';
    }
    if (email.trim() && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
        newErrors.email = 'Email inválido.'
    }
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!validate()) return;

    const contactData = { name, whatsapp, email, status, notes };
    if (contactToEdit) {
      updateContact(contactToEdit.id, contactData);
    } else {
      addContact(contactData);
    }
    onClose();
  };
  
  const statusOptions = Object.values(ContactStatus).map(s => ({ value: s, label: s }));

  return (
    <form onSubmit={handleSubmit} className="space-y-4">
      <Input 
        label="Nome Completo *" 
        id="contact-name" 
        value={name} 
        onChange={(e) => setName(e.target.value)} 
        error={errors.name}
        required 
      />
      <Input 
        label="WhatsApp *" 
        id="contact-whatsapp"
        type="tel"
        value={whatsapp} 
        onChange={(e) => setWhatsapp(e.target.value)} 
        placeholder="Ex: 5511999998888"
        error={errors.whatsapp}
        required 
      />
      <Input 
        label="Email" 
        id="contact-email"
        type="email"
        value={email} 
        onChange={(e) => setEmail(e.target.value)} 
        error={errors.email}
      />
      <Select
        label="Status *"
        id="contact-status"
        value={status}
        onChange={(e) => setStatus(e.target.value as ContactStatus)}
        options={statusOptions}
        required
      />
      <Textarea 
        label="Observações" 
        id="contact-notes"
        value={notes} 
        onChange={(e) => setNotes(e.target.value)} 
      />
      <div className="flex justify-end space-x-3 pt-2">
        <Button type="button" variant="ghost" onClick={onClose}>Cancelar</Button>
        <Button type="submit">{contactToEdit ? 'Salvar Alterações' : 'Adicionar Contato'}</Button>
      </div>
    </form>
  );
};
    