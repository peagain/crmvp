
import React from 'react';
import { Contact, ContactStatus } from '../../types';
import { Button } from '../ui/Button';
import { PencilIcon } from '../icons/PencilIcon';
import { TrashIcon } from '../icons/TrashIcon';
import { ChatBubbleLeftEllipsisIcon } from '../icons/ChatBubbleLeftEllipsisIcon';
import { WHATSAPP_BASE_URL } from '../../constants';

interface ContactItemProps {
  contact: Contact;
  onEdit: (contact: Contact) => void;
  onDelete: (contactId: string) => void;
}

const statusColors: Record<ContactStatus, string> = {
  [ContactStatus.LEAD]: 'bg-blue-100 text-blue-700',
  [ContactStatus.CONTACTED]: 'bg-yellow-100 text-yellow-700',
  [ContactStatus.SCHEDULED]: 'bg-indigo-100 text-indigo-700',
  [ContactStatus.NEGOTIATION]: 'bg-purple-100 text-purple-700',
  [ContactStatus.CONVERTED]: 'bg-green-100 text-green-700',
  [ContactStatus.LOST]: 'bg-red-100 text-red-700',
};

export const ContactItem: React.FC<ContactItemProps> = ({ contact, onEdit, onDelete }) => {
  const whatsappLink = `${WHATSAPP_BASE_URL}${contact.whatsapp.replace(/\D/g, '')}`;

  return (
    <li className="bg-white shadow-md rounded-lg p-4 hover:shadow-lg transition-shadow duration-200">
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center">
        <div>
          <h3 className="text-lg font-semibold text-primary">{contact.name}</h3>
          <p className="text-sm text-neutral">WhatsApp: {contact.whatsapp}</p>
          {contact.email && <p className="text-sm text-neutral">Email: {contact.email}</p>}
          <p className="text-xs text-gray-500 mt-1">
            Criado em: {new Date(contact.createdAt).toLocaleDateString('pt-BR')}
          </p>
        </div>
        <div className="mt-3 sm:mt-0 flex flex-col items-start sm:items-end space-y-2">
           <span className={`px-2 py-1 text-xs font-semibold rounded-full ${statusColors[contact.status]}`}>
            {contact.status}
          </span>
          <div className="flex space-x-2 mt-2 sm:mt-0">
             <a href={whatsappLink} target="_blank" rel="noopener noreferrer">
                <Button variant="ghost" size="sm" aria-label="Abrir WhatsApp">
                    <ChatBubbleLeftEllipsisIcon className="h-4 w-4" />
                </Button>
            </a>
            <Button variant="ghost" size="sm" onClick={() => onEdit(contact)} aria-label="Editar Contato">
              <PencilIcon className="h-4 w-4" />
            </Button>
            <Button variant="ghost" size="sm" onClick={() => onDelete(contact.id)} className="text-red-500 hover:text-red-700" aria-label="Excluir Contato">
              <TrashIcon className="h-4 w-4" />
            </Button>
          </div>
        </div>
      </div>
      {contact.notes && (
        <div className="mt-3 pt-3 border-t border-gray-200">
          <p className="text-sm text-neutral-dark font-medium">Observações:</p>
          <p className="text-sm text-neutral whitespace-pre-wrap">{contact.notes}</p>
        </div>
      )}
    </li>
  );
};
    