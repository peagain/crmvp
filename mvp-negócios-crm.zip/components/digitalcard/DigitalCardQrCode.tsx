
import React from 'react';

interface DigitalCardQrCodeProps {
  url: string;
  size?: number;
}

export const DigitalCardQrCode: React.FC<DigitalCardQrCodeProps> = ({ url, size = 200 }) => {
  // Using an external API for QR code generation as per constraints
  const qrApiUrl = `https://api.qrserver.com/v1/create-qr-code/?data=${encodeURIComponent(url)}&size=${size}x${size}&ecc=M&margin=10`;

  return (
    <div className="flex flex-col items-center">
      <img 
        src={qrApiUrl} 
        alt="QR Code do Cartão Digital" 
        width={size} 
        height={size}
        className="border-4 border-gray-200 rounded-lg shadow-md"
      />
      <p className="mt-2 text-xs text-neutral text-center">
        Escaneie para acessar o Cartão Digital.
      </p>
    </div>
  );
};
    