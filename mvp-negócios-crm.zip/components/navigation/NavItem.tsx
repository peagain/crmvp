
import React from 'react';
import { NavLink } from 'react-router-dom';

interface NavItemProps {
  to: string;
  icon: React.ReactNode;
  children: React.ReactNode;
  onClick?: () => void;
}

export const NavItem: React.FC<NavItemProps> = ({ to, icon, children, onClick }) => {
  const commonClasses = "flex items-center px-3 py-2 rounded-md text-sm font-medium transition-colors duration-150 ease-in-out";
  const activeClassName = "bg-primary text-white";
  const inactiveClassName = "text-neutral-dark hover:bg-gray-200 hover:text-neutral-dark";

  return (
    <NavLink
      to={to}
      onClick={onClick}
      className={({ isActive }) => `${commonClasses} ${isActive ? activeClassName : inactiveClassName}`}
    >
      <span className="mr-3 h-5 w-5">{icon}</span>
      {children}
    </NavLink>
  );
};
    