
import React, { useState } from 'react';
import { NavLink } from 'react-router-dom';
import { NavItem } from './NavItem';
import { HomeIcon } from '../icons/HomeIcon';
import { UserGroupIcon } from '../icons/UserGroupIcon';
import { CalendarDaysIcon } from '../icons/CalendarDaysIcon';
import { TagIcon } from '../icons/TagIcon';
import { IdentificationIcon } from '../icons/IdentificationIcon';
import { XMarkIcon } from '../icons/XMarkIcon';
import { Bars3Icon } from '../icons/Bars3Icon'; // Assuming you create this icon

export const Navbar: React.FC = () => {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const navLinks = [
    { to: "/dashboard", icon: <HomeIcon className="h-5 w-5"/>, label: "Dashboard" },
    { to: "/crm", icon: <UserGroupIcon className="h-5 w-5"/>, label: "CRM" },
    { to: "/scheduler", icon: <CalendarDaysIcon className="h-5 w-5"/>, label: "Agenda" },
    { to: "/offers", icon: <TagIcon className="h-5 w-5"/>, label: "Ofertas" },
    { to: "/digital-card-config", icon: <IdentificationIcon className="h-5 w-5"/>, label: "Cartão Digital" },
  ];

  return (
    <nav className="bg-white shadow-md sticky top-0 z-40">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          <div className="flex items-center">
            <NavLink to="/dashboard" className="flex-shrink-0">
              <span className="text-2xl font-bold text-primary">MVP Negócios</span>
            </NavLink>
          </div>
          <div className="hidden md:block">
            <div className="ml-10 flex items-baseline space-x-4">
              {navLinks.map(link => (
                <NavItem key={link.to} to={link.to} icon={link.icon}>
                  {link.label}
                </NavItem>
              ))}
            </div>
          </div>
          <div className="-mr-2 flex md:hidden">
            <button
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              type="button"
              className="bg-white inline-flex items-center justify-center p-2 rounded-md text-gray-400 hover:text-gray-500 hover:bg-gray-100 focus:outline-none focus:ring-2 focus:ring-inset focus:ring-primary"
              aria-controls="mobile-menu"
              aria-expanded="false"
            >
              <span className="sr-only">Abrir menu principal</span>
              {mobileMenuOpen ? (
                <XMarkIcon className="block h-6 w-6" aria-hidden="true" />
              ) : (
                <Bars3Icon className="block h-6 w-6" aria-hidden="true" />
              )}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile menu, show/hide based on menu state. */}
      {mobileMenuOpen && (
        <div className="md:hidden" id="mobile-menu">
          <div className="px-2 pt-2 pb-3 space-y-1 sm:px-3">
            {navLinks.map(link => (
              <NavItem key={link.to} to={link.to} icon={link.icon} onClick={() => setMobileMenuOpen(false)}>
                {link.label}
              </NavItem>
            ))}
          </div>
        </div>
      )}
    </nav>
  );
};

// Create Bars3Icon.tsx if it doesn't exist
// components/icons/Bars3Icon.tsx
// import React from 'react';
// export const Bars3Icon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
//   <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" {...props}>
//     <path strokeLinecap="round" strokeLinejoin="round" d="M3.75 6.75h16.5M3.75 12h16.5m-16.5 5.25h16.5" />
//   </svg>
// );
    