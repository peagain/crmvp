
import React, { useState, useMemo } from 'react';
import { Contact, OfferTemplate } from '../../types';
import { useAppContext } from '../../contexts/AppContext';
import { Button } from '../ui/Button';
import { Modal } from '../ui/Modal';
import { Select } from '../ui/Select';
import { Input } from '../ui/Input';
import { WHATSAPP_BASE_URL } from '../../constants';
import { PaperAirplaneIcon } from '../icons/PaperAirplaneIcon';

interface OfferDispatchModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const OfferDispatchModal: React.FC<OfferDispatchModalProps> = ({ isOpen, onClose }) => {
  const { contacts, offerTemplates, logSentOffer } = useAppContext();
  const [selectedOfferId, setSelectedOfferId] = useState<string>('');
  const [selectedContactIds, setSelectedContactIds] = useState<string[]>([]);
  const [searchTerm, setSearchTerm] = useState('');

  const filteredContacts = useMemo(() => {
    return contacts.filter(contact => 
      contact.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      contact.whatsapp.includes(searchTerm)
    );
  }, [contacts, searchTerm]);

  const handleToggleContactSelection = (contactId: string) => {
    setSelectedContactIds(prev =>
      prev.includes(contactId) ? prev.filter(id => id !== contactId) : [...prev, contactId]
    );
  };

  const handleSelectAllContacts = () => {
    if (selectedContactIds.length === filteredContacts.length) {
        setSelectedContactIds([]);
    } else {
        setSelectedContactIds(filteredContacts.map(c => c.id));
    }
  };

  const generateLinks = () => {
    if (!selectedOfferId || selectedContactIds.length === 0) return [];
    
    const offer = offerTemplates.find(o => o.id === selectedOfferId);
    if (!offer) return [];

    return selectedContactIds.map(contactId => {
      const contact = contacts.find(c => c.id === contactId);
      if (!contact) return null;
      
      const message = offer.message.replace(/\[NOME_CLIENTE\]/g, contact.name.split(' ')[0]); // Use first name
      logSentOffer({contactId, offerTemplateId: offer.id, sentAt: new Date().toISOString()});
      return {
        name: contact.name,
        link: `${WHATSAPP_BASE_URL}${contact.whatsapp.replace(/\D/g, '')}?text=${encodeURIComponent(message)}`
      };
    }).filter(Boolean);
  };

  const links = generateLinks();

  const offerOptions = offerTemplates.map(o => ({ value: o.id, label: o.name }));

  return (
    <Modal isOpen={isOpen} onClose={onClose} title="Disparar Oferta via WhatsApp" size="xl">
      <div className="space-y-4">
        <Select
          label="Selecionar Modelo de Oferta *"
          options={offerOptions}
          value={selectedOfferId}
          onChange={(e) => setSelectedOfferId(e.target.value)}
          placeholder="Escolha uma oferta..."
        />

        <div>
          <Input 
            label="Buscar Contatos"
            placeholder="Nome ou WhatsApp..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="mb-2"
          />
          {filteredContacts.length > 0 && (
            <Button onClick={handleSelectAllContacts} variant="outline" size="sm" className="mb-2">
                {selectedContactIds.length === filteredContacts.length ? 'Desmarcar Todos' : 'Marcar Todos Visíveis'}
            </Button>
          )}
          <div className="max-h-60 overflow-y-auto border rounded-md p-2 space-y-1">
            {filteredContacts.length > 0 ? filteredContacts.map(contact => (
              <div key={contact.id} className="flex items-center p-2 hover:bg-gray-100 rounded">
                <input
                  type="checkbox"
                  id={`contact-check-${contact.id}`}
                  checked={selectedContactIds.includes(contact.id)}
                  onChange={() => handleToggleContactSelection(contact.id)}
                  className="h-4 w-4 text-primary border-gray-300 rounded focus:ring-primary mr-3"
                />
                <label htmlFor={`contact-check-${contact.id}`} className="flex-grow cursor-pointer">
                    {contact.name} ({contact.whatsapp})
                </label>
              </div>
            )) : <p className="text-neutral text-sm p-2">Nenhum contato encontrado.</p>}
          </div>
          <p className="text-xs text-gray-500 mt-1">{selectedContactIds.length} contato(s) selecionado(s).</p>
        </div>

        {links.length > 0 && (
          <div>
            <h4 className="font-semibold mb-2 text-neutral-dark">Links Gerados:</h4>
            <ul className="space-y-2 max-h-48 overflow-y-auto">
              {links.map((item, index) => item && (
                <li key={index} className="flex items-center justify-between p-2 bg-neutral-light rounded-md">
                  <span>{item.name}</span>
                  <a href={item.link} target="_blank" rel="noopener noreferrer">
                    <Button variant="primary" size="sm" rightIcon={<PaperAirplaneIcon className="h-4 w-4"/>}>
                      Enviar
                    </Button>
                  </a>
                </li>
              ))}
            </ul>
            <p className="text-xs text-gray-500 mt-2">Clique em "Enviar" para abrir o WhatsApp com a mensagem preenchida para cada contato.</p>
          </div>
        )}

        <div className="flex justify-end space-x-3 pt-4">
          <Button variant="ghost" onClick={onClose}>Fechar</Button>
          {/* The "Generate Links" is implicit now */}
        </div>
      </div>
    </Modal>
  );
};
    