
import React, { useState, useEffect } from 'react';
import { OfferTemplate } from '../../types';
import { Button } from '../ui/Button';
import { Input } from '../ui/Input';
import { Textarea } from '../ui/Textarea';
import { useAppContext } from '../../contexts/AppContext';

interface OfferFormProps {
  onClose: () => void;
  offerToEdit?: OfferTemplate;
}

export const OfferForm: React.FC<OfferFormProps> = ({ onClose, offerToEdit }) => {
  const { addOfferTemplate, updateOfferTemplate } = useAppContext();
  const [name, setName] = useState('');
  const [message, setMessage] = useState('');
  const [errors, setErrors] = useState<{ [key: string]: string }>({});

  useEffect(() => {
    if (offerToEdit) {
      setName(offerToEdit.name);
      setMessage(offerToEdit.message);
    } else {
      setName('');
      setMessage('');
    }
  }, [offerToEdit]);

  const validate = (): boolean => {
    const newErrors: { [key: string]: string } = {};
    if (!name.trim()) newErrors.name = 'Nome do modelo é obrigatório.';
    if (!message.trim()) newErrors.message = 'Mensagem da oferta é obrigatória.';
    else if (!message.includes('[NOME_CLIENTE]')) {
        newErrors.message = 'A mensagem deve incluir a tag [NOME_CLIENTE] para personalização.'
    }
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!validate()) return;

    const offerData = { name, message };
    if (offerToEdit) {
      updateOfferTemplate(offerToEdit.id, offerData);
    } else {
      addOfferTemplate(offerData);
    }
    onClose();
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-4">
      <Input 
        label="Nome do Modelo de Oferta *" 
        id="offer-name" 
        value={name} 
        onChange={(e) => setName(e.target.value)} 
        error={errors.name}
        required 
      />
      <Textarea 
        label="Mensagem da Oferta *" 
        id="offer-message"
        value={message} 
        onChange={(e) => setMessage(e.target.value)} 
        error={errors.message}
        rows={5}
        required
        placeholder="Ex: Olá [NOME_CLIENTE], temos uma oferta especial para você..."
      />
      <p className="text-xs text-gray-500">
        Use <code>[NOME_CLIENTE]</code> para personalizar a mensagem com o nome do contato.
      </p>
      <div className="flex justify-end space-x-3 pt-2">
        <Button type="button" variant="ghost" onClick={onClose}>Cancelar</Button>
        <Button type="submit">{offerToEdit ? 'Salvar Alterações' : 'Criar Modelo'}</Button>
      </div>
    </form>
  );
};
    