
import React, { useState, useEffect } from 'react';
import { Appointment, AppointmentStatus, Contact } from '../../types';
import { Button } from '../ui/Button';
import { Input } from '../ui/Input';
import { Textarea } from '../ui/Textarea';
import { Select } from '../ui/Select';
import { useAppContext } from '../../contexts/AppContext';

interface AppointmentFormProps {
  onClose: () => void;
  appointmentToEdit?: Appointment;
  initialContactId?: string; // Pre-select contact if adding from contact view
}

export const AppointmentForm: React.FC<AppointmentFormProps> = ({ onClose, appointmentToEdit, initialContactId }) => {
  const { contacts, addAppointment, updateAppointment, findContactById } = useAppContext();
  
  const [contactId, setContactId] = useState<string>(initialContactId || '');
  const [title, setTitle] = useState('');
  const [dateTime, setDateTime] = useState('');
  const [notes, setNotes] = useState('');
  const [status, setStatus] = useState<AppointmentStatus>(AppointmentStatus.SCHEDULED);
  const [errors, setErrors] = useState<{ [key: string]: string }>({});

  useEffect(() => {
    if (appointmentToEdit) {
      setContactId(appointmentToEdit.contactId);
      setTitle(appointmentToEdit.title);
      // Format date for datetime-local input
      const localDateTime = new Date(appointmentToEdit.dateTime);
      localDateTime.setMinutes(localDateTime.getMinutes() - localDateTime.getTimezoneOffset()); // Adjust for local timezone
      setDateTime(localDateTime.toISOString().slice(0, 16));
      setNotes(appointmentToEdit.notes || '');
      setStatus(appointmentToEdit.status);
    } else {
        setContactId(initialContactId || (contacts.length > 0 ? contacts[0].id : ''));
        setTitle('');
        setDateTime('');
        setNotes('');
        setStatus(AppointmentStatus.SCHEDULED);
    }
  }, [appointmentToEdit, initialContactId, contacts]);

  const validate = (): boolean => {
    const newErrors: { [key: string]: string } = {};
    if (!contactId) newErrors.contactId = 'Cliente é obrigatório.';
    if (!title.trim()) newErrors.title = 'Título é obrigatório.';
    if (!dateTime) newErrors.dateTime = 'Data e Hora são obrigatórios.';
    else if (new Date(dateTime) < new Date() && !appointmentToEdit) { // Only for new appointments or if date changed
      // For editing, allow past dates if status is Completed/Cancelled
      if (status === AppointmentStatus.SCHEDULED) {
           // newErrors.dateTime = 'Data e Hora não podem ser no passado.';
      }
    }
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!validate()) return;

    const selectedContact = findContactById(contactId);

    const appointmentData = { 
      contactId, 
      contactName: selectedContact?.name,
      title, 
      dateTime: new Date(dateTime).toISOString(), // Store as ISO string
      notes,
      status
    };

    if (appointmentToEdit) {
      updateAppointment(appointmentToEdit.id, appointmentData);
    } else {
      addAppointment(appointmentData);
    }
    onClose();
  };

  const contactOptions = contacts.map(c => ({ value: c.id, label: c.name }));
  const statusOptions = Object.values(AppointmentStatus).map(s => ({ value: s, label: s }));

  return (
    <form onSubmit={handleSubmit} className="space-y-4">
      <Select
        label="Cliente *"
        id="appointment-contact"
        value={contactId}
        onChange={(e) => setContactId(e.target.value)}
        options={contactOptions}
        error={errors.contactId}
        required
        disabled={!!initialContactId && !appointmentToEdit} // Disable if adding for specific contact unless editing
      />
      <Input 
        label="Título do Agendamento *" 
        id="appointment-title" 
        value={title} 
        onChange={(e) => setTitle(e.target.value)} 
        error={errors.title}
        required 
      />
      <Input 
        label="Data e Hora *" 
        id="appointment-datetime"
        type="datetime-local"
        value={dateTime} 
        onChange={(e) => setDateTime(e.target.value)} 
        error={errors.dateTime}
        required 
      />
       <Select
        label="Status *"
        id="appointment-status"
        value={status}
        onChange={(e) => setStatus(e.target.value as AppointmentStatus)}
        options={statusOptions}
        required
      />
      <Textarea 
        label="Observações" 
        id="appointment-notes"
        value={notes} 
        onChange={(e) => setNotes(e.target.value)} 
      />
      <div className="flex justify-end space-x-3 pt-2">
        <Button type="button" variant="ghost" onClick={onClose}>Cancelar</Button>
        <Button type="submit">{appointmentToEdit ? 'Salvar Alterações' : 'Agendar'}</Button>
      </div>
    </form>
  );
};
    