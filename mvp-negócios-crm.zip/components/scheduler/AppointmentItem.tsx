
import React from 'react';
import { Appointment, AppointmentStatus, Contact } from '../../types';
import { Button } from '../ui/Button';
import { PencilIcon } from '../icons/PencilIcon';
import { TrashIcon } from '../icons/TrashIcon';
import { ChatBubbleLeftEllipsisIcon } from '../icons/ChatBubbleLeftEllipsisIcon';
import { useAppContext } from '../../contexts/AppContext';
import { WHATSAPP_BASE_URL } from '../../constants';

interface AppointmentItemProps {
  appointment: Appointment;
  onEdit: (appointment: Appointment) => void;
  onDelete: (appointmentId: string) => void;
}

const statusColors: Record<AppointmentStatus, string> = {
  [AppointmentStatus.SCHEDULED]: 'bg-blue-100 text-blue-700',
  [AppointmentStatus.COMPLETED]: 'bg-green-100 text-green-700',
  [AppointmentStatus.CANCELLED]: 'bg-red-100 text-red-700',
};


export const AppointmentItem: React.FC<AppointmentItemProps> = ({ appointment, onEdit, onDelete }) => {
  const { findContactById } = useAppContext();
  const contact = findContactById(appointment.contactId);

  const formattedDateTime = new Date(appointment.dateTime).toLocaleString('pt-BR', {
    dateStyle: 'full',
    timeStyle: 'short'
  });

  const generateWhatsAppReminderLink = () => {
    if (!contact) return '#';
    const message = `Olá ${contact.name}, lembrete do seu agendamento: "${appointment.title}" para ${new Date(appointment.dateTime).toLocaleDateString('pt-BR', {day:'2-digit', month:'2-digit'})} às ${new Date(appointment.dateTime).toLocaleTimeString('pt-BR', {hour:'2-digit', minute:'2-digit'})}.`;
    return `${WHATSAPP_BASE_URL}${contact.whatsapp.replace(/\D/g, '')}?text=${encodeURIComponent(message)}`;
  };

  return (
    <li className="bg-white shadow-md rounded-lg p-4 hover:shadow-lg transition-shadow duration-200">
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center">
        <div>
          <h3 className="text-lg font-semibold text-primary">{appointment.title}</h3>
          <p className="text-sm text-neutral">
            Cliente: {appointment.contactName || contact?.name || 'Desconhecido'}
            {contact && (<span className="text-xs text-gray-400"> ({contact.whatsapp})</span>)}
          </p>
          <p className="text-sm text-neutral-dark font-medium">{formattedDateTime}</p>
        </div>
        <div className="mt-3 sm:mt-0 flex flex-col items-start sm:items-end space-y-2">
          <span className={`px-2 py-1 text-xs font-semibold rounded-full ${statusColors[appointment.status]}`}>
            {appointment.status}
          </span>
          <div className="flex space-x-2 mt-2 sm:mt-0">
            {contact && appointment.status === AppointmentStatus.SCHEDULED && (
               <a href={generateWhatsAppReminderLink()} target="_blank" rel="noopener noreferrer">
                <Button variant="ghost" size="sm" className="text-green-600 hover:text-green-700" aria-label="Enviar Lembrete">
                    <ChatBubbleLeftEllipsisIcon className="h-4 w-4" />
                </Button>
              </a>
            )}
            <Button variant="ghost" size="sm" onClick={() => onEdit(appointment)} aria-label="Editar Agendamento">
              <PencilIcon className="h-4 w-4" />
            </Button>
            <Button variant="ghost" size="sm" onClick={() => onDelete(appointment.id)} className="text-red-500 hover:text-red-700" aria-label="Excluir Agendamento">
              <TrashIcon className="h-4 w-4" />
            </Button>
          </div>
        </div>
      </div>
      {appointment.notes && (
        <div className="mt-3 pt-3 border-t border-gray-200">
          <p className="text-sm text-neutral-dark font-medium">Observações:</p>
          <p className="text-sm text-neutral whitespace-pre-wrap">{appointment.notes}</p>
        </div>
      )}
    </li>
  );
};
    