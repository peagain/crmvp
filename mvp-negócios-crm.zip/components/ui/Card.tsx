
import React from 'react';

interface CardProps {
  children: React.ReactNode;
  title?: string;
  className?: string;
  titleClassName?: string;
  bodyClassName?: string;
  actions?: React.ReactNode; // For buttons or links in the header
}

export const Card: React.FC<CardProps> = ({ children, title, className = '', titleClassName='', bodyClassName='', actions }) => {
  return (
    <div className={`bg-white shadow-lg rounded-xl overflow-hidden ${className}`}>
      {title && (
        <div className={`p-4 sm:p-6 border-b border-gray-200 flex justify-between items-center ${titleClassName}`}>
          <h3 className="text-lg sm:text-xl font-semibold text-neutral-dark">{title}</h3>
          {actions && <div>{actions}</div>}
        </div>
      )}
      <div className={`p-4 sm:p-6 ${bodyClassName}`}>
        {children}
      </div>
    </div>
  );
};
    