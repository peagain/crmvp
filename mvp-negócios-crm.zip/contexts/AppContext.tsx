
import React, { createContext, useContext, ReactNode } from 'react';
import { Contact, Appointment, OfferTemplate, DigitalCardConfig, SentOfferInfo } from '../types';
import { useLocalStorage } from '../hooks/useLocalStorage';
import { INITIAL_CONTACTS, INITIAL_APPOINTMENTS, INITIAL_OFFER_TEMPLATES, DEFAULT_DIGITAL_CARD_CONFIG } from '../constants';

interface AppContextType {
  contacts: Contact[];
  addContact: (contact: Omit<Contact, 'id' | 'createdAt'>) => Contact;
  updateContact: (id: string, updates: Partial<Omit<Contact, 'id' | 'createdAt'>>) => void;
  deleteContact: (id: string) => void;
  findContactById: (id: string) => Contact | undefined;

  appointments: Appointment[];
  addAppointment: (appointment: Omit<Appointment, 'id'>) => Appointment;
  updateAppointment: (id: string, updates: Partial<Omit<Appointment, 'id'>>) => void;
  deleteAppointment: (id: string) => void;
  getAppointmentsForContact: (contactId: string) => Appointment[];

  offerTemplates: OfferTemplate[];
  addOfferTemplate: (template: Omit<OfferTemplate, 'id'>) => OfferTemplate;
  updateOfferTemplate: (id: string, updates: Partial<Omit<OfferTemplate, 'id'>>) => void;
  deleteOfferTemplate: (id: string) => void;

  digitalCardConfig: DigitalCardConfig;
  updateDigitalCardConfig: (config: Partial<DigitalCardConfig>) => void;

  sentOffers: SentOfferInfo[];
  logSentOffer: (info: SentOfferInfo) => void;
}

const AppContext = createContext<AppContextType | undefined>(undefined);

export const AppProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [contacts, setContacts] = useLocalStorage<Contact[]>('mvpnegocios_contacts', INITIAL_CONTACTS);
  const [appointments, setAppointments] = useLocalStorage<Appointment[]>('mvpnegocios_appointments', INITIAL_APPOINTMENTS);
  const [offerTemplates, setOfferTemplates] = useLocalStorage<OfferTemplate[]>('mvpnegocios_offers', INITIAL_OFFER_TEMPLATES);
  const [digitalCardConfig, setDigitalCardConfig] = useLocalStorage<DigitalCardConfig>('mvpnegocios_digitalcard', DEFAULT_DIGITAL_CARD_CONFIG);
  const [sentOffers, setSentOffers] = useLocalStorage<SentOfferInfo[]>('mvpnegocios_sentoffers', []);

  const addContact = (contactData: Omit<Contact, 'id' | 'createdAt'>): Contact => {
    const newContact: Contact = { ...contactData, id: crypto.randomUUID(), createdAt: new Date().toISOString() };
    setContacts(prev => [...prev, newContact]);
    return newContact;
  };

  const updateContact = (id: string, updates: Partial<Omit<Contact, 'id' | 'createdAt'>>) => {
    setContacts(prev => prev.map(c => c.id === id ? { ...c, ...updates } : c));
  };

  const deleteContact = (id: string) => {
    setContacts(prev => prev.filter(c => c.id !== id));
    setAppointments(prev => prev.filter(a => a.contactId !== id)); // Also remove related appointments
  };
  
  const findContactById = (id: string): Contact | undefined => contacts.find(c => c.id === id);

  const addAppointment = (appointmentData: Omit<Appointment, 'id'>): Appointment => {
    const newAppointment: Appointment = { ...appointmentData, id: crypto.randomUUID() };
    setAppointments(prev => [...prev, newAppointment]);
    return newAppointment;
  };

  const updateAppointment = (id: string, updates: Partial<Omit<Appointment, 'id'>>) => {
    setAppointments(prev => prev.map(a => a.id === id ? { ...a, ...updates } : a));
  };

  const deleteAppointment = (id: string) => {
    setAppointments(prev => prev.filter(a => a.id !== id));
  };

  const getAppointmentsForContact = (contactId: string) => {
    return appointments.filter(a => a.contactId === contactId);
  };

  const addOfferTemplate = (templateData: Omit<OfferTemplate, 'id'>): OfferTemplate => {
    const newTemplate: OfferTemplate = { ...templateData, id: crypto.randomUUID() };
    setOfferTemplates(prev => [...prev, newTemplate]);
    return newTemplate;
  };

  const updateOfferTemplate = (id: string, updates: Partial<Omit<OfferTemplate, 'id'>>) => {
    setOfferTemplates(prev => prev.map(t => t.id === id ? { ...t, ...updates } : t));
  };

  const deleteOfferTemplate = (id: string) => {
    setOfferTemplates(prev => prev.filter(t => t.id !== id));
  };
  
  const updateDigitalCardConfig = (config: Partial<DigitalCardConfig>) => {
    setDigitalCardConfig(prev => ({...prev, ...config}));
  };

  const logSentOffer = (info: SentOfferInfo) => {
    setSentOffers(prev => [...prev, info]);
  };

  return (
    <AppContext.Provider value={{
      contacts, addContact, updateContact, deleteContact, findContactById,
      appointments, addAppointment, updateAppointment, deleteAppointment, getAppointmentsForContact,
      offerTemplates, addOfferTemplate, updateOfferTemplate, deleteOfferTemplate,
      digitalCardConfig, updateDigitalCardConfig,
      sentOffers, logSentOffer
    }}>
      {children}
    </AppContext.Provider>
  );
};

export const useAppContext = (): AppContextType => {
  const context = useContext(AppContext);
  if (context === undefined) {
    throw new Error('useAppContext must be used within an AppProvider');
  }
  return context;
};
    