
import React, { useState, useMemo } from 'react';
import { useAppContext } from '../contexts/AppContext';
import { Contact } from '../types';
import { Button } from '../components/ui/Button';
import { Modal } from '../components/ui/Modal';
import { Input } from '../components/ui/Input';
import { ContactForm } from '../components/crm/ContactForm';
import { ContactItem } from '../components/crm/ContactItem';
import { PlusCircleIcon } from '../components/icons/PlusCircleIcon';
import { Card } from '../components/ui/Card';

export const CrmPage: React.FC = () => {
  const { contacts, deleteContact } = useAppContext();
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [contactToEdit, setContactToEdit] = useState<Contact | undefined>(undefined);
  const [searchTerm, setSearchTerm] = useState('');

  const openModalForNew = () => {
    setContactToEdit(undefined);
    setIsModalOpen(true);
  };

  const openModalForEdit = (contact: Contact) => {
    setContactToEdit(contact);
    setIsModalOpen(true);
  };

  const handleDeleteContact = (id: string) => {
    if (window.confirm('Tem certeza que deseja excluir este contato e todos os seus agendamentos?')) {
      deleteContact(id);
    }
  };

  const filteredContacts = useMemo(() => {
    return contacts
      .filter(contact => 
        contact.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
        contact.whatsapp.includes(searchTerm) ||
        (contact.email && contact.email.toLowerCase().includes(searchTerm.toLowerCase()))
      )
      .sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
  }, [contacts, searchTerm]);

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row justify-between items-center">
        <h1 className="text-3xl font-bold text-neutral-dark">Gerenciador de Contatos (CRM)</h1>
        <Button onClick={openModalForNew} leftIcon={<PlusCircleIcon className="h-5 w-5"/>}>
          Novo Contato
        </Button>
      </div>

      <Card>
        <Input 
          placeholder="Buscar contatos por nome, WhatsApp ou email..."
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
          className="mb-4"
        />
        {filteredContacts.length > 0 ? (
          <ul className="space-y-4">
            {filteredContacts.map(contact => (
              <ContactItem 
                key={contact.id} 
                contact={contact} 
                onEdit={openModalForEdit} 
                onDelete={handleDeleteContact} 
              />
            ))}
          </ul>
        ) : (
          <p className="text-center text-neutral py-8">
            {contacts.length === 0 ? "Nenhum contato cadastrado ainda." : "Nenhum contato encontrado com o termo buscado."}
          </p>
        )}
      </Card>

      <Modal
        isOpen={isModalOpen}
        onClose={() => setIsModalOpen(false)}
        title={contactToEdit ? 'Editar Contato' : 'Novo Contato'}
      >
        <ContactForm 
          onClose={() => setIsModalOpen(false)} 
          contactToEdit={contactToEdit} 
        />
      </Modal>
    </div>
  );
};
    