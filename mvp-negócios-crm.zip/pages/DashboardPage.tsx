
import React from 'react';
import { Link } from 'react-router-dom';
import { useAppContext } from '../contexts/AppContext';
import { Card } from '../components/ui/Card';
import { Button } from '../components/ui/Button';
import { UserGroupIcon } from '../components/icons/UserGroupIcon';
import { CalendarDaysIcon } from '../components/icons/CalendarDaysIcon';
import { TagIcon } from '../components/icons/TagIcon';
import { IdentificationIcon } from '../components/icons/IdentificationIcon';
import { ContactStatus, AppointmentStatus, DigitalCardConfig } from '../types';

export const DashboardPage: React.FC = () => {
  const { contacts, appointments, offerTemplates, digitalCardConfig } = useAppContext();

  const upcomingAppointments = appointments
    .filter(a => new Date(a.dateTime) > new Date() && a.status === AppointmentStatus.SCHEDULED)
    .sort((a, b) => new Date(a.dateTime).getTime() - new Date(b.dateTime).getTime())
    .slice(0, 3);

  const recentLeads = contacts
    .filter(c => c.status === ContactStatus.LEAD)
    .sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime())
    .slice(0, 3);

  const stats = [
    { label: 'Total de Contatos', value: contacts.length, icon: <UserGroupIcon className="h-8 w-8 text-primary" />, link: '/crm' },
    { label: 'Agendamentos Próximos', value: upcomingAppointments.length, icon: <CalendarDaysIcon className="h-8 w-8 text-secondary" />, link: '/scheduler' },
    { label: 'Modelos de Oferta', value: offerTemplates.length, icon: <TagIcon className="h-8 w-8 text-accent" />, link: '/offers' },
    { label: 'Novos Leads', value: contacts.filter(c => c.status === ContactStatus.LEAD).length, icon: <UserGroupIcon className="h-8 w-8 text-yellow-500" />, link: '/crm' },
  ];

  const buildPublicCardQueryString = (config: DigitalCardConfig): string => {
    const queryParams = new URLSearchParams();
    queryParams.append('bn', config.businessName);
    queryParams.append('tagline', config.tagline || '');
    queryParams.append('wn', config.whatsappNumber);
    queryParams.append('wpm', config.whatsappPrefillMessage || '');
    queryParams.append('slt', config.schedulingSystem);
    if (config.schedulingSystem === 'external' && config.externalSchedulingLink) {
      queryParams.append('esl', config.externalSchedulingLink);
    }
    
    const logoUrlForParam = config.logoUrl || `https://picsum.photos/seed/${encodeURIComponent(config.businessName)}/100`;
    queryParams.append('logo', logoUrlForParam);
    
    queryParams.append('pc', config.primaryColor);
    queryParams.append('ac', config.accentColor);
    return queryParams.toString();
  };

  const publicCardQueryString = buildPublicCardQueryString(digitalCardConfig);
  // This is the path including '#' that HashRouter expects
  const publicCardHashPath = `#/public-card?${publicCardQueryString}`;

  return (
    <div className="space-y-6">
      <h1 className="text-3xl font-bold text-neutral-dark">Dashboard</h1>
      
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {stats.map(stat => (
          <Link to={stat.link} key={stat.label} className="block hover:shadow-xl transition-shadow duration-200 rounded-xl">
            <Card className="h-full">
              <div className="flex items-center space-x-4">
                <div className="p-3 bg-primary-light rounded-full">
                  {stat.icon}
                </div>
                <div>
                  <p className="text-sm text-neutral font-medium">{stat.label}</p>
                  <p className="text-2xl font-semibold text-neutral-dark">{stat.value}</p>
                </div>
              </div>
            </Card>
          </Link>
        ))}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <Card title="Próximos Agendamentos">
          {upcomingAppointments.length > 0 ? (
            <ul className="space-y-3">
              {upcomingAppointments.map(app => (
                <li key={app.id} className="p-3 bg-neutral-light rounded-md">
                  <Link to="/scheduler" className="block hover:bg-gray-50 p-2 rounded-md">
                    <p className="font-semibold text-primary">{app.title} com {app.contactName || 'Contato Desconhecido'}</p>
                    <p className="text-sm text-neutral">{new Date(app.dateTime).toLocaleString('pt-BR', { dateStyle: 'short', timeStyle: 'short' })}</p>
                  </Link>
                </li>
              ))}
            </ul>
          ) : (
            <p className="text-neutral">Nenhum agendamento próximo.</p>
          )}
           <Link to="/scheduler" className="mt-4 inline-block text-sm text-primary hover:underline">Ver todos os agendamentos &rarr;</Link>
        </Card>

        <Card title="Leads Recentes">
          {recentLeads.length > 0 ? (
            <ul className="space-y-3">
              {recentLeads.map(contact => (
                <li key={contact.id} className="p-3 bg-neutral-light rounded-md">
                   <Link to="/crm" className="block hover:bg-gray-50 p-2 rounded-md">
                    <p className="font-semibold text-primary">{contact.name}</p>
                    <p className="text-sm text-neutral">WhatsApp: {contact.whatsapp}</p>
                    <p className="text-xs text-gray-500">Adicionado em: {new Date(contact.createdAt).toLocaleDateString('pt-BR')}</p>
                  </Link>
                </li>
              ))}
            </ul>
          ) : (
            <p className="text-neutral">Nenhum lead recente.</p>
          )}
          <Link to="/crm" className="mt-4 inline-block text-sm text-primary hover:underline">Ver todos os contatos &rarr;</Link>
        </Card>
      </div>

      <Card title="Acesso Rápido ao Cartão Digital">
        <div className="flex flex-col sm:flex-row items-center space-y-4 sm:space-y-0 sm:space-x-6">
            <IdentificationIcon className="h-16 w-16 text-primary" />
          <div>
            <h3 className="text-xl font-semibold text-neutral-dark">{digitalCardConfig.businessName}</h3>
            <p className="text-neutral">{digitalCardConfig.tagline}</p>
            <div className="mt-4 space-x-3">
                <Link to="/digital-card-config">
                    <Button variant="outline">Configurar Cartão</Button>
                </Link>
                <a 
                    href={publicCardHashPath} // Use only the hash path
                    target="_blank" 
                    rel="noopener noreferrer"
                >
                   <Button variant="primary">Ver Cartão Digital</Button>
                </a>
            </div>
          </div>
        </div>
      </Card>
    </div>
  );
};
