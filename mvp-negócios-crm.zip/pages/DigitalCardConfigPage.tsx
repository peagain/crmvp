
import React, { useState, useEffect } from 'react';
import { useAppContext } from '../contexts/AppContext';
import { DigitalCardConfig } from '../types';
import { Button } from '../components/ui/Button';
import { Input } from '../components/ui/Input';
import { Textarea } from '../components/ui/Textarea';
import { Select } from '../components/ui/Select';
import { Card } from '../components/ui/Card';
import { DigitalCardQrCode } from '../components/digitalcard/DigitalCardQrCode';

export const DigitalCardConfigPage: React.FC = () => {
  const { digitalCardConfig, updateDigitalCardConfig } = useAppContext();
  const [config, setConfig] = useState<DigitalCardConfig>(digitalCardConfig);
  const [publicCardUrl, setPublicCardUrl] = useState(''); // For QR Code (full URL)
  const [publicCardHashPathOnly, setPublicCardHashPathOnly] = useState(''); // For clickable link (hash path only)

  useEffect(() => {
    setConfig(digitalCardConfig);
  }, [digitalCardConfig]);
  
  useEffect(() => {
    const params = new URLSearchParams();
    params.append('bn', config.businessName);
    params.append('tagline', config.tagline || '');
    params.append('wn', config.whatsappNumber);
    params.append('wpm', config.whatsappPrefillMessage || '');
    params.append('slt', config.schedulingSystem);
    if (config.schedulingSystem === 'external') {
      params.append('esl', config.externalSchedulingLink || '');
    }
    params.append('logo', config.logoUrl || `https://picsum.photos/seed/${encodeURIComponent(config.businessName)}/100`);
    params.append('pc', config.primaryColor);
    params.append('ac', config.accentColor);
    
    const queryString = params.toString();
    const hashPath = `#/public-card?${queryString}`;
    setPublicCardHashPathOnly(hashPath);

    // For QR Code, we still need the full URL
    const documentLocation = window.location.href.split('#')[0];
    setPublicCardUrl(documentLocation + hashPath);

  }, [config]);


  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    setConfig(prev => ({ ...prev, [name]: value }));
  };

  const handleSave = () => {
    updateDigitalCardConfig(config);
    alert('Configurações salvas!');
  };

  const schedulingSystemOptions = [
    { value: 'internal', label: 'Formulário Interno de Captura' },
    { value: 'external', label: 'Link Externo (Ex: Calendly)' },
  ];

  return (
    <div className="space-y-6">
      <h1 className="text-3xl font-bold text-neutral-dark">Configurar Cartão Digital</h1>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <Card title="Informações do Cartão" className="lg:col-span-2">
          <form className="space-y-4">
            <Input label="Nome do Negócio" name="businessName" value={config.businessName} onChange={handleChange} />
            <Input label="Slogan / Tagline" name="tagline" value={config.tagline || ''} onChange={handleChange} />
            <Input label="URL da Logo" name="logoUrl" value={config.logoUrl || ''} onChange={handleChange} placeholder="https://picsum.photos/100"/>
            <Input label="Número do WhatsApp (para 'Falar Agora')" name="whatsappNumber" type="tel" value={config.whatsappNumber} onChange={handleChange} placeholder="5511999998888" />
            <Textarea label="Mensagem Pré-preenchida do WhatsApp" name="whatsappPrefillMessage" value={config.whatsappPrefillMessage || ''} onChange={handleChange} rows={2} placeholder="Olá, gostaria de mais informações." />
            
            <h3 className="text-md font-semibold pt-2 text-neutral-dark">Agendamento</h3>
            <Select 
              label="Sistema de Agendamento" 
              name="schedulingSystem" 
              options={schedulingSystemOptions} 
              value={config.schedulingSystem} 
              onChange={handleChange} 
            />
            {config.schedulingSystem === 'external' && (
              <Input label="Link Externo de Agendamento" name="externalSchedulingLink" value={config.externalSchedulingLink || ''} onChange={handleChange} placeholder="https://calendly.com/seu-link" />
            )}
             <h3 className="text-md font-semibold pt-2 text-neutral-dark">Cores</h3>
             <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <Input label="Cor Primária (Hex)" name="primaryColor" type="color" value={config.primaryColor} onChange={handleChange} wrapperClassName="flex flex-col" className="h-10"/>
                <Input label="Cor de Destaque (Hex)" name="accentColor" type="color" value={config.accentColor} onChange={handleChange} wrapperClassName="flex flex-col" className="h-10"/>
             </div>


            <Button type="button" onClick={handleSave} className="w-full sm:w-auto">Salvar Configurações</Button>
          </form>
        </Card>

        <Card title="QR Code e Link" className="lg:col-span-1">
          <div className="space-y-4 text-center">
            {publicCardUrl && <DigitalCardQrCode url={publicCardUrl} size={200} /> }
            <p className="text-sm text-neutral-dark">Link do Cartão (para QR Code):</p>
            <Input 
              readOnly 
              value={publicCardUrl} 
              onClick={(e) => (e.target as HTMLInputElement).select()} 
              className="text-center text-xs"
            />
             <a href={publicCardHashPathOnly} target="_blank" rel="noopener noreferrer">
                <Button variant="outline" className="w-full">
                    Visualizar Cartão Digital
                </Button>
            </a>
          </div>
        </Card>
      </div>
    </div>
  );
};
