
import React, { useState, useEffect } from 'react';
import { useLocation, useNavigate } from 'react-router-dom';
import { useAppContext } from '../contexts/AppContext';
import { Button } from '../components/ui/Button';
import { Input } from '../components/ui/Input';
import { Textarea } from '../components/ui/Textarea';
import { ContactStatus } from '../types';
import { Card } from '../components/ui/Card';

export const LeadCapturePage: React.FC = () => {
  const { addContact } = useAppContext();
  const navigate = useNavigate();
  const location = useLocation();

  const [name, setName] = useState('');
  const [whatsapp, setWhatsapp] = useState('');
  const [message, setMessage] = useState('');
  const [businessName, setBusinessName] = useState('');
  const [isSubmitted, setIsSubmitted] = useState(false);
  const [errors, setErrors] = useState<{ [key: string]: string }>({});

  useEffect(() => {
    const params = new URLSearchParams(location.search);
    setBusinessName(params.get('bn') || 'seu negócio');
    // could prefill message based on params too, if needed
  }, [location.search]);

  const validate = (): boolean => {
    const newErrors: { [key: string]: string } = {};
    if (!name.trim()) newErrors.name = 'Seu nome é obrigatório.';
    if (!whatsapp.trim()) {
      newErrors.whatsapp = 'Seu WhatsApp é obrigatório.';
    } else if (!/^\+?[0-9\s-()]{10,}$/.test(whatsapp)) {
      newErrors.whatsapp = 'Número de WhatsApp inválido.';
    }
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!validate()) return;

    const notes = `Lead capturado via Cartão Digital para ${businessName}. ${message ? `Mensagem: ${message}` : ''}`.trim();
    addContact({
      name,
      whatsapp,
      status: ContactStatus.LEAD,
      notes,
    });
    setIsSubmitted(true);
    // Optionally redirect after a delay or provide a button to go back
    // setTimeout(() => navigate('/'), 3000);
  };
  
  // This page should also ideally not have the main app's navbar.
  // Similar considerations as PublicDigitalCardPage.

  if (isSubmitted) {
    return (
      <div className="min-h-screen flex flex-col items-center justify-center p-4 bg-neutral-light">
         <style>{`
            body { background-color: #f3f4f6 !important; } /* neutral-light */
            nav { display: none !important; } 
            footer { display: none !important; }
        `}</style>
        <Card title="Obrigado!">
          <div className="text-center space-y-4">
            <p className="text-lg text-neutral-dark">Seus dados foram enviados com sucesso para {businessName}!</p>
            <p className="text-neutral">Entraremos em contato em breve.</p>
            {/* <Button onClick={() => navigate('/')}>Voltar ao Início</Button> */}
             <p className="text-xs text-gray-400 mt-4">Você pode fechar esta janela.</p>
          </div>
        </Card>
      </div>
    );
  }

  return (
    <div className="min-h-screen flex flex-col items-center justify-center p-4 bg-neutral-light">
         <style>{`
            body { background-color: #f3f4f6 !important; } /* neutral-light */
            nav { display: none !important; } 
            footer { display: none !important; }
        `}</style>
      <Card title={`Solicitar Agendamento com ${businessName}`} className="w-full max-w-lg">
        <p className="text-sm text-neutral mb-6">Preencha os campos abaixo e aguarde nosso contato.</p>
        <form onSubmit={handleSubmit} className="space-y-4">
          <Input 
            label="Seu Nome Completo *" 
            id="lead-name" 
            value={name} 
            onChange={(e) => setName(e.target.value)} 
            error={errors.name}
            required 
          />
          <Input 
            label="Seu WhatsApp *" 
            id="lead-whatsapp"
            type="tel"
            value={whatsapp} 
            onChange={(e) => setWhatsapp(e.target.value)} 
            placeholder="Ex: 5511999998888"
            error={errors.whatsapp}
            required 
          />
          <Textarea 
            label="Mensagem (Opcional)" 
            id="lead-message"
            value={message} 
            onChange={(e) => setMessage(e.target.value)} 
            placeholder="Ex: Gostaria de agendar um horário na parte da tarde."
            rows={3}
          />
          <Button type="submit" className="w-full">Enviar Solicitação</Button>
        </form>
      </Card>
       <p className="text-xs text-gray-400 mt-8">Powered by MVP Negócios</p>
    </div>
  );
};
    