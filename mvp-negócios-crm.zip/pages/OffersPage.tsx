
import React, { useState } from 'react';
import { useAppContext } from '../contexts/AppContext';
import { OfferTemplate } from '../types';
import { Button } from '../components/ui/Button';
import { Modal } from '../components/ui/Modal';
import { Card } from '../components/ui/Card';
import { OfferForm } from '../components/offers/OfferForm';
import { OfferDispatchModal } from '../components/offers/OfferDispatchModal';
import { PlusCircleIcon } from '../components/icons/PlusCircleIcon';
import { PencilIcon } from '../components/icons/PencilIcon';
import { TrashIcon } from '../components/icons/TrashIcon';
import { PaperAirplaneIcon } from '../components/icons/PaperAirplaneIcon';

export const OffersPage: React.FC = () => {
  const { offerTemplates, deleteOfferTemplate, contacts } = useAppContext();
  const [isFormModalOpen, setIsFormModalOpen] = useState(false);
  const [isDispatchModalOpen, setIsDispatchModalOpen] = useState(false);
  const [offerToEdit, setOfferToEdit] = useState<OfferTemplate | undefined>(undefined);

  const openFormModalForNew = () => {
    setOfferToEdit(undefined);
    setIsFormModalOpen(true);
  };

  const openFormModalForEdit = (offer: OfferTemplate) => {
    setOfferToEdit(offer);
    setIsFormModalOpen(true);
  };

  const handleDeleteOffer = (id: string) => {
    if (window.confirm('Tem certeza que deseja excluir este modelo de oferta?')) {
      deleteOfferTemplate(id);
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row justify-between items-center">
        <h1 className="text-3xl font-bold text-neutral-dark">Modelos de Oferta</h1>
        <div className="flex space-x-2 mt-4 sm:mt-0">
            <Button 
                onClick={openFormModalForNew} 
                leftIcon={<PlusCircleIcon className="h-5 w-5"/>}
                variant="secondary"
            >
            Novo Modelo
            </Button>
            <Button 
                onClick={() => setIsDispatchModalOpen(true)} 
                leftIcon={<PaperAirplaneIcon className="h-5 w-5"/>}
                disabled={offerTemplates.length === 0 || contacts.length === 0}
            >
            Disparar Oferta
            </Button>
        </div>
      </div>
      
      {contacts.length === 0 && (
         <p className="text-center text-amber-700 bg-amber-100 p-3 rounded-md">
            Você precisa cadastrar contatos no CRM para poder disparar ofertas.
        </p>
      )}
      {offerTemplates.length === 0 && (
         <p className="text-center text-amber-700 bg-amber-100 p-3 rounded-md">
            Você precisa criar modelos de oferta para poder dispará-las.
        </p>
      )}


      {offerTemplates.length > 0 ? (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {offerTemplates.map(offer => (
            <Card key={offer.id} title={offer.name} className="flex flex-col justify-between">
              <p className="text-sm text-neutral mb-4 flex-grow whitespace-pre-wrap">
                {offer.message.length > 150 ? `${offer.message.substring(0, 147)}...` : offer.message}
              </p>
              <div className="flex justify-end space-x-2 pt-3 border-t">
                <Button variant="ghost" size="sm" onClick={() => openFormModalForEdit(offer)} aria-label="Editar Modelo">
                  <PencilIcon className="h-4 w-4" />
                </Button>
                <Button variant="ghost" size="sm" onClick={() => handleDeleteOffer(offer.id)} className="text-red-500 hover:text-red-700" aria-label="Excluir Modelo">
                  <TrashIcon className="h-4 w-4" />
                </Button>
              </div>
            </Card>
          ))}
        </div>
      ) : (
        <Card>
            <p className="text-center text-neutral py-8">
            Nenhum modelo de oferta cadastrado ainda. Crie um para começar!
            </p>
        </Card>
      )}

      <Modal
        isOpen={isFormModalOpen}
        onClose={() => setIsFormModalOpen(false)}
        title={offerToEdit ? 'Editar Modelo de Oferta' : 'Novo Modelo de Oferta'}
      >
        <OfferForm 
          onClose={() => setIsFormModalOpen(false)} 
          offerToEdit={offerToEdit} 
        />
      </Modal>

      {isDispatchModalOpen && (
        <OfferDispatchModal 
            isOpen={isDispatchModalOpen}
            onClose={() => setIsDispatchModalOpen(false)}
        />
      )}
    </div>
  );
};
    