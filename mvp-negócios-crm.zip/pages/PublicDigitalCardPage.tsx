
import React, { useEffect, useState } from 'react';
import { useLocation, Link as RouterLink } from 'react-router-dom';
import { Button } from '../components/ui/Button';
import { WHATSAPP_BASE_URL } from '../constants';
import { DEFAULT_DIGITAL_CARD_CONFIG } from '../constants';
import { ChatBubbleLeftEllipsisIcon } from '../components/icons/ChatBubbleLeftEllipsisIcon';
import { CalendarDaysIcon } from '../components/icons/CalendarDaysIcon';

interface CardDisplayConfig {
  businessName: string;
  tagline: string;
  whatsappNumber: string;
  whatsappPrefillMessage: string;
  schedulingSystem: 'internal' | 'external';
  externalSchedulingLink?: string;
  logoUrl: string;
  primaryColor: string;
  accentColor: string;
}

export const PublicDigitalCardPage: React.FC = () => {
  const location = useLocation();
  const [config, setConfig] = useState<CardDisplayConfig | null>(null);

  useEffect(() => {
    const params = new URLSearchParams(location.search);
    setConfig({
      businessName: params.get('bn') || DEFAULT_DIGITAL_CARD_CONFIG.businessName,
      tagline: params.get('tagline') || DEFAULT_DIGITAL_CARD_CONFIG.tagline || '',
      whatsappNumber: params.get('wn') || DEFAULT_DIGITAL_CARD_CONFIG.whatsappNumber,
      whatsappPrefillMessage: params.get('wpm') || DEFAULT_DIGITAL_CARD_CONFIG.whatsappPrefillMessage || '',
      schedulingSystem: (params.get('slt') as 'internal' | 'external') || DEFAULT_DIGITAL_CARD_CONFIG.schedulingSystem,
      externalSchedulingLink: params.get('esl') || DEFAULT_DIGITAL_CARD_CONFIG.externalSchedulingLink,
      logoUrl: params.get('logo') || DEFAULT_DIGITAL_CARD_CONFIG.logoUrl || `https://picsum.photos/seed/${encodeURIComponent(params.get('bn') || 'default')}/150`,
      primaryColor: params.get('pc') || DEFAULT_DIGITAL_CARD_CONFIG.primaryColor,
      accentColor: params.get('ac') || DEFAULT_DIGITAL_CARD_CONFIG.accentColor,
    });
  }, [location.search]);

  if (!config) {
    return <div className="flex items-center justify-center min-h-screen bg-gray-100 text-gray-700">Carregando cartão...</div>;
  }

  const talkNowLink = `${WHATSAPP_BASE_URL}${config.whatsappNumber.replace(/\D/g, '')}?text=${encodeURIComponent(config.whatsappPrefillMessage)}`;
  
  const scheduleLinkParams = new URLSearchParams();
  scheduleLinkParams.append('bn', config.businessName); // Pass business name for context
  const internalScheduleLink = `/lead-capture?${scheduleLinkParams.toString()}`;


  // Basic styling for the public card page
  // This page should ideally not have the main app's navbar.
  // The App.tsx structure implies it will, need to consider making it a distinct layout or full page.
  // For now, it will be inside the main layout. For a real app, this would be a separate, minimal HTML template.

  return (
    <div className="min-h-screen flex flex-col items-center justify-center p-4" style={{ backgroundColor: config.primaryColor }}>
        <style>{`
            body { background-color: ${config.primaryColor} !important; }
            nav { display: none !important; } /* Attempt to hide navbar, might not be robust */
            footer { display: none !important; }
        `}</style>
      <div className="bg-white shadow-2xl rounded-xl p-6 sm:p-10 w-full max-w-md text-center transform transition-all hover:scale-105 duration-300">
        {config.logoUrl && (
          <img 
            src={config.logoUrl} 
            alt={`${config.businessName} Logo`} 
            className="w-24 h-24 sm:w-32 sm:h-32 rounded-full mx-auto mb-6 border-4"
            style={{ borderColor: config.accentColor }}
          />
        )}
        <h1 className="text-3xl sm:text-4xl font-bold mb-2" style={{ color: config.primaryColor }}>{config.businessName}</h1>
        {config.tagline && <p className="text-neutral-dark text-md sm:text-lg mb-8">{config.tagline}</p>}

        <div className="space-y-4">
          <a href={talkNowLink} target="_blank" rel="noopener noreferrer" className="block">
            <Button 
              variant="primary" 
              size="lg" 
              className="w-full !text-lg"
              style={{ backgroundColor: config.accentColor, borderColor: config.accentColor }}
              leftIcon={<ChatBubbleLeftEllipsisIcon className="h-6 w-6" />}
            >
              Falar Agora no WhatsApp
            </Button>
          </a>

          {config.schedulingSystem === 'internal' ? (
            <RouterLink to={internalScheduleLink} className="block">
              <Button 
                variant="outline" 
                size="lg" 
                className="w-full !text-lg"
                style={{ color: config.accentColor, borderColor: config.accentColor }}
                leftIcon={<CalendarDaysIcon className="h-6 w-6" />}
                >
                Agendar Atendimento
              </Button>
            </RouterLink>
          ) : (
            <a href={config.externalSchedulingLink} target="_blank" rel="noopener noreferrer" className="block">
              <Button 
                variant="outline" 
                size="lg" 
                className="w-full !text-lg"
                style={{ color: config.accentColor, borderColor: config.accentColor }}
                leftIcon={<CalendarDaysIcon className="h-6 w-6" />}
                >
                Agendar Atendimento
              </Button>
            </a>
          )}
        </div>
      </div>
      <p className="text-xs text-white opacity-70 mt-8">Powered by MVP Negócios</p>
    </div>
  );
};
    