
import React, { useState, useMemo } from 'react';
import { Link } from 'react-router-dom'; // Added import
import { useAppContext } from '../contexts/AppContext';
import { Appointment, AppointmentStatus } from '../types';
import { Button } from '../components/ui/Button';
import { Modal } from '../components/ui/Modal';
import { AppointmentForm } from '../components/scheduler/AppointmentForm';
import { AppointmentItem } from '../components/scheduler/AppointmentItem';
import { PlusCircleIcon } from '../components/icons/PlusCircleIcon';
import { Card } from '../components/ui/Card';
import { Select } from '../components/ui/Select'; // For filtering

export const SchedulerPage: React.FC = () => {
  const { appointments, deleteAppointment, contacts } = useAppContext();
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [appointmentToEdit, setAppointmentToEdit] = useState<Appointment | undefined>(undefined);
  const [filterStatus, setFilterStatus] = useState<string>(''); // All, Scheduled, Completed, Cancelled
  const [filterDate, setFilterDate] = useState<'all' | 'today' | 'upcoming' | 'past'>('upcoming');

  const openModalForNew = () => {
    setAppointmentToEdit(undefined);
    setIsModalOpen(true);
  };

  const openModalForEdit = (appointment: Appointment) => {
    setAppointmentToEdit(appointment);
    setIsModalOpen(true);
  };

  const handleDeleteAppointment = (id: string) => {
    if (window.confirm('Tem certeza que deseja excluir este agendamento?')) {
      deleteAppointment(id);
    }
  };

  const filteredAppointments = useMemo(() => {
    const now = new Date();
    const todayStart = new Date(now.getFullYear(), now.getMonth(), now.getDate());
    const todayEnd = new Date(now.getFullYear(), now.getMonth(), now.getDate() + 1);

    return appointments
      .filter(app => {
        if (filterStatus && app.status !== filterStatus) return false;
        const appDate = new Date(app.dateTime);
        if (filterDate === 'today' && (appDate < todayStart || appDate >= todayEnd)) return false;
        if (filterDate === 'upcoming' && appDate < now && app.status === AppointmentStatus.SCHEDULED) return false;
        if (filterDate === 'past' && appDate >= now) return false;
        return true;
      })
      .sort((a, b) => new Date(a.dateTime).getTime() - new Date(b.dateTime).getTime());
  }, [appointments, filterStatus, filterDate]);
  
  const statusFilterOptions = [
    { value: '', label: 'Todos os Status' },
    ...Object.values(AppointmentStatus).map(s => ({ value: s, label: s }))
  ];

  const dateFilterOptions = [
    { value: 'all', label: 'Todas as Datas' },
    { value: 'upcoming', label: 'Próximos' },
    { value: 'today', label: 'Hoje' },
    { value: 'past', label: 'Passados' },
  ];


  if (contacts.length === 0) {
    return (
       <Card title="Agenda de Compromissos">
            <div className="text-center py-8">
                <p className="text-xl text-neutral-dark mb-4">Você precisa cadastrar contatos antes de criar agendamentos.</p>
                <Link to="/crm">
                    <Button variant="primary">Ir para CRM</Button>
                </Link>
            </div>
        </Card>
    )
  }


  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row justify-between items-center">
        <h1 className="text-3xl font-bold text-neutral-dark">Agenda de Compromissos</h1>
        <Button onClick={openModalForNew} leftIcon={<PlusCircleIcon className="h-5 w-5"/>} disabled={contacts.length === 0}>
          Novo Agendamento
        </Button>
      </div>

      <Card>
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 mb-4">
            <Select
                label="Filtrar por Status"
                options={statusFilterOptions}
                value={filterStatus}
                onChange={(e) => setFilterStatus(e.target.value)}
            />
            <Select
                label="Filtrar por Data"
                options={dateFilterOptions}
                value={filterDate}
                onChange={(e) => setFilterDate(e.target.value as 'all' | 'today' | 'upcoming' | 'past')}
            />
        </div>
        {filteredAppointments.length > 0 ? (
          <ul className="space-y-4">
            {filteredAppointments.map(appointment => (
              <AppointmentItem 
                key={appointment.id} 
                appointment={appointment} 
                onEdit={openModalForEdit} 
                onDelete={handleDeleteAppointment} 
              />
            ))}
          </ul>
        ) : (
          <p className="text-center text-neutral py-8">
            {appointments.length === 0 ? "Nenhum agendamento cadastrado ainda." : "Nenhum agendamento encontrado com os filtros aplicados."}
          </p>
        )}
      </Card>

      <Modal
        isOpen={isModalOpen}
        onClose={() => setIsModalOpen(false)}
        title={appointmentToEdit ? 'Editar Agendamento' : 'Novo Agendamento'}
      >
        <AppointmentForm 
          onClose={() => setIsModalOpen(false)} 
          appointmentToEdit={appointmentToEdit} 
        />
      </Modal>
    </div>
  );
};